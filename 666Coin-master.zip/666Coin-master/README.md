**666Coin (666)**

666Coin is an innovative, secure and energy efficient PoW/PoS coin. It uses a faster PoW distribution mechanism to distribute the initial coins, then after 4 weeks the coin is basically transferred to a pure PoS coin, where the generation of the coin is mainly through the PoS interests.

666Coin also adopt a variable PoS rate, which gives the highest payout at 100% the first year, then decrease 1/3 per year until the 5th year it reaches annual interest rate of 5%, then it will remain at this rate.

Because after 5 weeks it is basically a pure PoS coin, it does not need to be intensively mined, as the PoW payout will remain the minimum. Most coins will be generated through PoS, thus it is a coin that will save a lot of energy compared to other coins.

666Coin will have a total of 66.6 millions coins. The PoW payout will be halved each month.

PoS will start after at least 30 days of holding of the coins in the wallet. With PoS, the coin is more resilient to 51% attack. 

**Other Specifications:**

- 666 seconds block target
- 66.6 coins on first year, after 6 coins before block 66600, after PoW will end
- PoW payout will be halved every month
- Difficulty retargets every block 
- PoS variable interests:
	- 1st year: 100%
	- 2nd year: 75%
	- 3rd year: 50%
        - 4rd year: 25%
        - 5rd year: 10%
	- 6th and subsequent years: 5%
- Total coins will be 66.6 millions
- 4 confirmations for transaction, thus fast 2 mins confirmation for transactions
- 25 confirmations for minted blocks
- 6.66% premine for bounties, giveaways, development, support and maintenance, new feature developments etc.

- Ports: 16661 (connection) and 19991 (RPC)
