# yuncms-coin

The coin module for yuncms.

[![Latest Stable Version](https://poser.pugx.org/yuncms/yuncms-coin/v/stable.png)](https://packagist.org/packages/yuncms/yuncms-coin)
[![Total Downloads](https://poser.pugx.org/yuncms/yuncms-coin/downloads.png)](https://packagist.org/packages/yuncms/yuncms-coin)
[![Build Status](https://img.shields.io/travis/yuncms/yuncms-coin.svg)](http://travis-ci.org/yuncms/yuncms-coin)
[![License](https://poser.pugx.org/yuncms/yuncms-coin/license.svg)](https://packagist.org/packages/yuncms/yuncms-coin)

## Installation

The preferred way to install this extension is through [composer](http://getcomposer.org/download/).

Either run

```bash
$ composer require yuncms/yuncms-coin
```

or add

```
"yuncms/yuncms-coin": "~2.0.0"
```

to the `require` section of your `composer.json` file.

## License

This is released under the MIT License. See the bundled [LICENSE](LICENSE.md)
for details.